package br.com.alura.gerenciador2.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Logout implements Tarefa {
	
	@Override
	public String executa(HttpServletRequest req, HttpServletResponse resp) {
		
		req.getSession().removeAttribute("usuarioLogado");
		return "/WEB-INF/paginas/logout.htmljsp";
	
		/*PrintWriter writer = resp.getWriter();
		writer.println("<html><body>Deslogado com sucesso!</body></html>"); 
		*/
		//resp.sendRedirect("logout.html");
		//RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/paginas/logout.html");
		//dispatcher.forward(req, resp);
		
		
	}

}
