package br.com.alura.gerenciador2.web;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.alura.gerenciador2.Empresa;
import br.com.alura.gerenciador2.dao.EmpresaDAO;


public class BuscaEmpresa  implements Tarefa{
	
	public BuscaEmpresa() {
		System.out.print("Construindo uma servLet do tipo BuscaEmpresa"+ this);
	}
	/*
	@Override
	public void init() throws ServletException {
		super.init();
		System.out.print("Inicializando a servLet"+ this);
	}
	
	@Override
	public void destroy() {
		super.destroy();
		System.out.print("Destruindo a servLet"+ this);
	}
	
	*/
	//String filtro;
	
	@Override
	public String executa(HttpServletRequest req, HttpServletResponse resp) {
		String filtro = req.getParameter("filtro");
		Collection<Empresa> empresas = new EmpresaDAO().buscaPorSimilaridade(filtro);
		req.setAttribute("empresas", empresas);
		return "/WEB-INF/paginas/buscaEmpresa.jsp";
	}
	/*
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
			*/
		
		//PrintWriter writer = resp.getWriter();
		
		/*
		writer.println("<html><body>");
		writer.println("Resultado da pesquisa:<br/>");
		*/
		//String filtro = req.getParameter("filtro");
		
		/*
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		*/
		/*
		Collection<Empresa> empresas = new EmpresaDAO().buscaPorSimilaridade(filtro);
		req.setAttribute("empresas", empresas);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/paginas/buscaEmpresa.jsp");
		dispatcher.forward(req, resp);
		*/
		/*	writer.println("<ul>");
	   for (Empresa empresa : empresas){
			writer.println("<li>" + empresa.getId() + ":"+ empresa.getNome());
			
	}
	   writer.println("</body></html>");
	   writer.println("</ul>");
	   */
}

