package br.com.alura.gerenciador2.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.alura.gerenciador2.Empresa;
import br.com.alura.gerenciador2.dao.EmpresaDAO;

public class NovaEmpresa implements Tarefa {
	
	@Override
	public String executa(HttpServletRequest req, HttpServletResponse resp)
			 {
		String nome = req.getParameter("nome");
		Empresa empresa = new Empresa(nome);
		new EmpresaDAO().adiciona(empresa);
		
		req.setAttribute("empresa", empresa);
		
		
		
		return "/WEB-INF/paginas/novaEmpresa.jsp";
		
		
		/*PrintWriter writer = resp.getWriter();
		writer.println("<html><body>Empresa adicionada com sucesso!:"+ " "+empresa.getNome()+"</body></html>");
		*/
	}
	

}



