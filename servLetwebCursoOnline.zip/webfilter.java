package br.com.alura.gerenciador2.web;

public @interface webfilter {

}
